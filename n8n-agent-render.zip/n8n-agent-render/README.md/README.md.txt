# n8n Agent via Render

Esse repositório permite subir um agente do n8n gratuito 24/7 usando Render.com.

## 🚀 Deploy 1-Click

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/Imerxshoe/n8n-agent-render)

---

## 📌 Como usar:

1. Clique no botão acima.
2. Preencha nome e senha do painel n8n.
3. Após o deploy, acesse: `https://nomedoprojeto.onrender.com`
4. Faça login com: `admin` + senha escolhida.
5. Importe seu fluxo JSON.
6. Copie a URL do webhook e cole no seu plugin WordPress.
